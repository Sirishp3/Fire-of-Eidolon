package sample;


public class Vestibule  {
    int row = 4;
    int column = 4;


    public int getRow() {
        return row;
    }


    public int getColumn() {
        return column;
    }
}
