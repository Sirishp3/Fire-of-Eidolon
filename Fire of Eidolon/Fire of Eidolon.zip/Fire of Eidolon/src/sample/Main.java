package sample;

import com.sun.xml.internal.bind.v2.model.core.NonElement;
import javafx.application.Application;
import javafx.application.HostServices;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.transform.Rotate;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.imageio.stream.FileImageInputStream;
import java.awt.*;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeMap;

public class Main extends Application {
    private int clickToPlay_Page = 0;
    private int selectClass_Page = 1;
    private int Play_Page = 2;
    private int ruleView_Page = 3;
    private int CurrentPage = clickToPlay_Page;

    private int TrackPageBeforeMovingToRules = -10;
    private Button goBack = new Button("Back");

    private String Player1_Class = "";
    private String Player2_Class = "";
    private String Player3_Class = "";
    private String Player4_Class = "";
    private String Player5_Class = "";
    private String Player6_Class = "";

    private boolean clickedOnChamberCardStack = false;
    private String[][] refGrid = new String[9][9];
    private GraphicsContext gc;
    private int canvasHeight = 1000;
    private int canvasWidth = 1100;
    private int tileLengths = 80;
    private int OutlineHeight = (tileLengths * 9) + 25 + 20;
    private int OutlineWidth = (tileLengths * 9) + 25 + 20;
    private Canvas canvas = new Canvas(canvasWidth, canvasHeight);

    private int countToCancel = 0;

    private File rules = new File("C:\\Users\\siris\\OneDrive\\Desktop\\FoE_manual_finalprint (1).pdf");

    private Image One = new Image("File:1.png", OutlineWidth, OutlineHeight, false, false);
    private Image Two = new Image("File:3.png", OutlineWidth, OutlineHeight, false, false);
    private Image Three = new Image("File:4.png", OutlineWidth, OutlineHeight, false, false);
    private Image Four = new Image("File:5.png", OutlineWidth, OutlineHeight, false, false);
    private Image Five = new Image("File:7.png", OutlineWidth, OutlineHeight, false, false);
    private Image Six = new Image("File:8.png", OutlineWidth, OutlineHeight, false, false);
    private Image Seven = new Image("File:9.png", OutlineWidth, OutlineHeight, false, false);
    private Image Eight = new Image("File:10.png", OutlineWidth, OutlineHeight, false, false);
    private Image Nine = new Image("File:11.png", OutlineWidth, OutlineHeight, false, false);
    private Image Ten = new Image("File:12.png", OutlineWidth, OutlineHeight, false, false);
    private Image Eleven = new Image("File:13.png", OutlineWidth, OutlineHeight, false, false);
    private Image Twelve = new Image("File:14.png", OutlineWidth, OutlineHeight, false, false);
    private Image Thirteen = new Image("File:15.png", OutlineWidth, OutlineHeight, false, false);
    private Image Fourteen = new Image("File:16.png", OutlineWidth, OutlineHeight, false, false);
    private Image Fifteen = new Image("File:17.png", OutlineWidth, OutlineHeight, false, false);
    private Image Sixteen = new Image("File:18.png", OutlineWidth, OutlineHeight, false, false);
    private Image Seventeen = new Image("File:19.png", OutlineWidth, OutlineHeight, false, false);
    private Image Eighteen = new Image("File:20.png", OutlineWidth, OutlineHeight, false, false);
    private Image Nineteen = new Image("File:21.png", OutlineWidth, OutlineHeight, false, false);
    private Image Twenty = new Image("File:22.png", OutlineWidth, OutlineHeight, false, false);
    private Image Twentyone = new Image("File:23.png", OutlineWidth, OutlineHeight, false, false);
    private Image Twentytwo = new Image("File:24.png", OutlineWidth, OutlineHeight, false, false);
    private Image Twentythree = new Image("File:25.png", OutlineWidth, OutlineHeight, false, false);
    private Image Twentyfour = new Image("File:26.png", OutlineWidth, OutlineHeight, false, false);
    private Image Twentyfive = new Image("File:27.png", OutlineWidth, OutlineHeight, false, false);
    private Image Twentysix = new Image("File:28.png", OutlineWidth, OutlineHeight, false, false);
    private Image Twentyseven = new Image("File:29.png", OutlineWidth, OutlineHeight, false, false);

    private Button Rules_leftbtn = new Button("<");
    private Button Rules_rightbtn = new Button(">");
    private int WhichRulePage = 1;


    private Image Outline = new Image("File:Outline.png", OutlineWidth, OutlineHeight, false, false);

    private Image Vestibule_img = new Image("File:Vestibule.png", tileLengths, tileLengths, false, false);
    private Image AcidJets_img = new Image("File:AcidJets.png", tileLengths, tileLengths, false, false);
    private Image ArrowTraps_img = new Image("File:ArrowTrap.png", tileLengths, tileLengths, false, false);
    private Image Blank_img = new Image("File:Blank.png", tileLengths, tileLengths, false, false);
    private Image DarkSlime_img = new Image("File:DarkSlime.png", tileLengths, tileLengths, false, false);
    private Image DenOfSnakes_img = new Image("File:DenOfSnakes.png", tileLengths, tileLengths, false, false);
    private Image Dragonling_img = new Image("File:Dragonling.png", tileLengths, tileLengths, false, false);
    private Image FelKnight_img = new Image("File:FelKnight.png", tileLengths, tileLengths, false, false);
    private Image FireOfEidolon_img = new Image("File:FireOfEidolon.png", tileLengths, tileLengths, false, false);
    private Image FloatingStones_img = new Image("File:FloatingStones.png", tileLengths, tileLengths, false, false);
    private Image HallOfIllusion_img = new Image("File:HallOfIllusion.png", tileLengths, tileLengths, false, false);
    private Image LaughingShadow_img = new Image("File:LaughingShadow.png", tileLengths, tileLengths, false, false);
    private Image LavaLake_img = new Image("File:LavaLake.png", tileLengths, tileLengths, false, false);
    private Image MimicChest_img = new Image("File:MimicChest.png", tileLengths, tileLengths, false, false);
    private Image MindEater_img = new Image("File:MindEater.png", tileLengths, tileLengths, false, false);
    private Image Minotaur_img = new Image("File:Minotaur.png", tileLengths, tileLengths, false, false);
    private Image NewExit_img = new Image("File:NewExit.png", tileLengths, tileLengths, false, false);
    private Image OgreBrute_img = new Image("File:OgreBrute.png", tileLengths, tileLengths, false, false);
    private Image ParadoxPuzzle_img = new Image("File:ParadoxPuzzle.png", tileLengths, tileLengths, false, false);
    private Image PendulumBlades_img = new Image("File:PendulumBlades.png", tileLengths, tileLengths, false, false);
    private Image Psychomancer_img = new Image("File:Psychomancer.png", tileLengths, tileLengths, false, false);
    private Image SecretPassageX_img = new Image("File:SecretPassageX.png", tileLengths, tileLengths, false, false);
    private Image SecretPassageY_img = new Image("File:SecretPassageY.png", tileLengths, tileLengths, false, false);
    private Image SkeletalGuards_img = new Image("File:SkeletalGuards.png", tileLengths, tileLengths, false, false);
    private Image SphynxsRiddle_img = new Image("File:SphynxsRiddle.png", tileLengths, tileLengths, false, false);
    private Image SpikedPit_img = new Image("File:SpikedPit.png", tileLengths, tileLengths, false, false);
    private Image VoraciousPlant_img = new Image("File:VoraciousPlant.png", tileLengths, tileLengths, false, false);
    private Image VoraxsFocus_img = new Image("File:VoraxsFocus.png", tileLengths, tileLengths, false, false);
    private Image VoraxsHeart_img = new Image("File:VoraxsHeart.png", tileLengths, tileLengths, false, false);
    private Image VoraxsKnowledge_img = new Image("File:VoraxsKnowledge.png", tileLengths, tileLengths, false, false);

    private ArrayList<String> AcidJets_doorplacements =  new ArrayList<>();
    private ArrayList<String> ArrowTraps_doorplacements = new ArrayList<>();
    private ArrayList<String> Blank_doorplacements = new ArrayList<>();
    private ArrayList<String> DarkSlime_doorplacements = new ArrayList<>();
    private ArrayList<String> DenOfSnakes_doorplacements = new ArrayList<>();
    private ArrayList<String> Dragonling_doorplacements = new ArrayList<>();
    private ArrayList<String> FelKnight_doorplacements = new ArrayList<>();
    private ArrayList<String>FireOfEidolon_doorplacements = new ArrayList<>();
    private ArrayList<String>FloatingStones_doorplacements = new ArrayList<>();
    private ArrayList<String>HallOfIllusion_doorplacements = new ArrayList<>();
    private ArrayList<String>LaughingShadow_doorplacements = new ArrayList<>();
    private ArrayList<String>LavaLake_doorplacements = new ArrayList<>();
    private ArrayList<String>MimicChest_doorplacements = new ArrayList<>();
    private ArrayList<String>MindEater_doorplacements = new ArrayList<>();
    private ArrayList<String>Minotaur_doorplacements = new ArrayList<>();
    private ArrayList<String>NewExit_doorplacements = new ArrayList<>();
    private ArrayList<String>OgreBrute_doorplacements = new ArrayList<>();
    private ArrayList<String>ParadoxPuzzle_doorplacements = new ArrayList<>();
    private ArrayList<String>PendulumBlades_doorplacements = new ArrayList<>();
    private ArrayList<String>Psychomancer_doorplacements = new ArrayList<>();
    private ArrayList<String>SecretPassageX_doorplacements = new ArrayList<>();
    private ArrayList<String>SecretPassageY_doorplacements = new ArrayList<>();
    private ArrayList<String>SkeletalGuards_doorplacements = new ArrayList<>();
    private ArrayList<String>SphynxsRiddle_doorplacements = new ArrayList<>();
    private ArrayList<String>SpikedPit_doorplacements = new ArrayList<>();
    private ArrayList<String>Vestibule_doorplacements = new ArrayList<>();
    private ArrayList<String>VoraciousPlant_doorplacements = new ArrayList<>();
    private ArrayList<String>VoraxsFocus_doorplacements = new ArrayList<>();
    private ArrayList<String>VoraxsHeart_doorplacements = new ArrayList<>();
    private ArrayList<String>VoraxsKnowledge_doorplacements = new ArrayList<>();


    private Image Cleric = new Image("File:Cleric.png");
    private Image DarkKnight = new Image("File:DarkKnight.png");
    private Image Engineer = new Image("File:Engineer.png");
    private Image Geomancer = new Image("File:Geomancer.png");
    private Image Paladin = new Image("File:Paladin.png");
    private Image Ranger = new Image("File:Ranger.png");
    private Image Rogue = new Image("File:Rogue.png");
    private Image Sage = new Image("File:Sage.png");
    private Image Soldier = new Image("File:Soldier.png");
    private Image Swordsman = new Image("File:Swordsman.png");
    private Image Warrior = new Image("File:Warrior.png");
    private Image Wizard = new Image("File:Wizard.png");


    private ArrayList<String> stackOfChamberTiles = new ArrayList<String>();
    private ArrayList<String> stackOfChamberTiles_DoorPlacements = new ArrayList<String>();


    private int NumOfPlayers = 0;
    private GridPane grid = new GridPane();
    private MenuBar menuBar = new MenuBar();
    private Menu menuPlayer = new Menu("Players");
    private Menu menuRules = new Menu("Rules");
    private MenuItem menuRules_btn = new MenuItem("View Rules");

    private ComboBox<String> Player1Class_CB = new ComboBox<>();
    private ComboBox<String> Player2Class_CB = new ComboBox<>();
    private ComboBox<String> Player3Class_CB = new ComboBox<>();
    private ComboBox<String> Player4Class_CB = new ComboBox<>();
    private ComboBox<String> Player5Class_CB = new ComboBox<>();
    private ComboBox<String> Player6Class_CB = new ComboBox<>();

    private Label player1_lbl = new Label("Player1:");
    private Label player2_lbl = new Label("Player2:");
    private Label player3_lbl = new Label("Player3:");
    private Label player4_lbl = new Label("Player4:");
    private Label player5_lbl = new Label("Player5:");
    private Label player6_lbl = new Label("Player6:");

    private boolean playersDoneSelecting = false;

    private int count = 0;

    Button verifyPlacement = new Button("Verify");
    Button rotate_btn = new Button("Rotate");

    @Override
    public void start(Stage primaryStage) throws Exception {
        //startOffFromHere
        //Work on DoorPlacement

        AcidJets_doorplacements.add("up");
         AcidJets_doorplacements.add("down");

         ArrowTraps_doorplacements .add("left");
         ArrowTraps_doorplacements .add("down");
         ArrowTraps_doorplacements .add("right");

        DarkSlime_doorplacements.add("right");
        DarkSlime_doorplacements.add("down");

        DenOfSnakes_doorplacements.add("up");
        DenOfSnakes_doorplacements.add("right");
        DenOfSnakes_doorplacements.add("down");

        Dragonling_doorplacements.add("up");
        Dragonling_doorplacements.add("left");
        Dragonling_doorplacements.add("down");

        FelKnight_doorplacements.add("up");
        FelKnight_doorplacements.add("right");
        FelKnight_doorplacements.add("down");

         FireOfEidolon_doorplacements.add("down");

         FloatingStones_doorplacements.add("up");
         FloatingStones_doorplacements.add("right");
         FloatingStones_doorplacements.add("down");
         FloatingStones_doorplacements.add("left");

         HallOfIllusion_doorplacements.add("right");
         HallOfIllusion_doorplacements.add("down");

         LaughingShadow_doorplacements.add("up");
         LaughingShadow_doorplacements.add("down");
         LaughingShadow_doorplacements.add("right");
         LaughingShadow_doorplacements.add("left");

         LavaLake_doorplacements.add("left");
         LavaLake_doorplacements.add("down");

         MimicChest_doorplacements.add("down");

         MindEater_doorplacements.add("left");
         MindEater_doorplacements.add("right");
         MindEater_doorplacements.add("down");

         Minotaur_doorplacements.add("up");
         Minotaur_doorplacements.add("down");
         Minotaur_doorplacements.add("right");
         Minotaur_doorplacements.add("left");

         NewExit_doorplacements.add("down");

         OgreBrute_doorplacements.add("left");
         OgreBrute_doorplacements.add("down");


         ParadoxPuzzle_doorplacements.add("up");
         ParadoxPuzzle_doorplacements.add("left");
         ParadoxPuzzle_doorplacements.add("down");

         PendulumBlades_doorplacements.add("up");
         PendulumBlades_doorplacements.add("down");


        Psychomancer_doorplacements.add("up");
        Psychomancer_doorplacements.add("down");
        Psychomancer_doorplacements.add("right");
        Psychomancer_doorplacements.add("left");

        SecretPassageX_doorplacements.add("up");;
        SecretPassageX_doorplacements.add("down");;
        SecretPassageX_doorplacements.add("right");;
        SecretPassageX_doorplacements.add("left");;


        SecretPassageY_doorplacements.add("up");
        SecretPassageY_doorplacements.add("down");
        SecretPassageY_doorplacements.add("right");
        SecretPassageY_doorplacements.add("left");


        SkeletalGuards_doorplacements.add("up");
        SkeletalGuards_doorplacements.add("down");

        SphynxsRiddle_doorplacements.add("up");
        SphynxsRiddle_doorplacements.add("down");

        SpikedPit_doorplacements.add("up");
        SpikedPit_doorplacements.add("right");
        SpikedPit_doorplacements.add("down");

        Vestibule_doorplacements.add("up");
        Vestibule_doorplacements.add("down");
        Vestibule_doorplacements.add("right");
        Vestibule_doorplacements.add("left");

        VoraciousPlant_doorplacements.add("up");
        VoraciousPlant_doorplacements.add("down");
        VoraciousPlant_doorplacements.add("right");
        VoraciousPlant_doorplacements.add("left");

        VoraxsFocus_doorplacements.add("down");

        VoraxsHeart_doorplacements.add("down");

        VoraxsKnowledge_doorplacements.add("down");


        stackOfChamberTiles.add("AcidJets");
        stackOfChamberTiles.add("ArrowTraps");
        stackOfChamberTiles.add("DarkSlime");
        stackOfChamberTiles.add("DenOfSnakes");
        stackOfChamberTiles.add("Dragonling");
        stackOfChamberTiles.add("FelKnight");
        stackOfChamberTiles.add("FireOfEidolon");
        stackOfChamberTiles.add("FloatingStones");
        stackOfChamberTiles.add("HallOfIllusion");
        stackOfChamberTiles.add("LaughingShadow");
        stackOfChamberTiles.add("LavaLake");
        stackOfChamberTiles.add("MimicChest");
        stackOfChamberTiles.add("MindEater");
        stackOfChamberTiles.add("Minotaur");
        stackOfChamberTiles.add("NewExit");
        stackOfChamberTiles.add("OgreBrute");
        stackOfChamberTiles.add("ParadoxPuzzle");
        stackOfChamberTiles.add("PendulumBlades");
        stackOfChamberTiles.add("Psychomancer");
        stackOfChamberTiles.add("SecretPassageX");
        stackOfChamberTiles.add("SecretPassageY");
        stackOfChamberTiles.add("SkeletalGuards");
        stackOfChamberTiles.add("SphynxsRiddle");
        stackOfChamberTiles.add("SpikedPit");
        stackOfChamberTiles.add("VoraciousPlant");
        stackOfChamberTiles.add("VoraxsFocus");
        stackOfChamberTiles.add("VoraxsHeart");
        stackOfChamberTiles.add("VoraxsKnowledge");

        randomizeStack();

        refGrid[4][4] = "Vestibule";
        RadioMenuItem OnePlayer = new RadioMenuItem("1");
        RadioMenuItem TwoPlayer = new RadioMenuItem("2");
        RadioMenuItem ThreePlayer = new RadioMenuItem("3");
        RadioMenuItem FourPlayer = new RadioMenuItem("4");
        RadioMenuItem FivePlayer = new RadioMenuItem("5");
        RadioMenuItem SixPlayer = new RadioMenuItem("6");
        RadioMenuItem SevenPlayer = new RadioMenuItem("7");
        RadioMenuItem EightPlayer = new RadioMenuItem("8");
        RadioMenuItem NinePlayer = new RadioMenuItem("9");
        RadioMenuItem TenPlayer = new RadioMenuItem("10");

        ToggleGroup playerList_ToggleGroup = new ToggleGroup();
        playerList_ToggleGroup.getToggles().addAll(OnePlayer, TwoPlayer, ThreePlayer, FourPlayer, FivePlayer, SixPlayer, SevenPlayer, EightPlayer, NinePlayer, TenPlayer);
        menuPlayer.getItems().addAll(OnePlayer, TwoPlayer, ThreePlayer, FourPlayer, FivePlayer, SixPlayer, SevenPlayer, EightPlayer, NinePlayer, TenPlayer);
        menuBar.getMenus().add(menuPlayer);
        menuRules.getItems().add(menuRules_btn);
        menuBar.getMenus().add(menuRules);
        grid.setGridLinesVisible(false);

        verifyPlacement.setMinSize(tileLengths, 25 + 10 + tileLengths);
        rotate_btn.setMinSize(tileLengths, rotate_btn.getHeight());

        grid.add(menuBar, 0, 0, 10, 1);
        grid.add(canvas, 0, 1, 4, 12);

        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        primaryStage.setTitle("Fire of Eidolon");
        Group group = new Group();
        group.getChildren().addAll(grid);
        gc = canvas.getGraphicsContext2D();
        if (CurrentPage == clickToPlay_Page)
            drawClickToPlayPage(gc);

        menuRules_btn.setOnAction(event -> {
            drawRules(gc, One);
            TrackPageBeforeMovingToRules = CurrentPage;
            CurrentPage = ruleView_Page;
            verifyPlacement.setVisible(false);
            rotate_btn.setVisible(false);

            Player1Class_CB.setVisible(false);
            Player2Class_CB.setVisible(false);
            Player3Class_CB.setVisible(false);
            Player4Class_CB.setVisible(false);
            Player5Class_CB.setVisible(false);
            Player6Class_CB.setVisible(false);

            player1_lbl.setVisible(false);
            player2_lbl.setVisible(false);
            player3_lbl.setVisible(false);
            player4_lbl.setVisible(false);
            player5_lbl.setVisible(false);
            player6_lbl.setVisible(false);

            Rules_rightbtn.setVisible(true);
            Rules_leftbtn.setVisible(true);
            goBack.setVisible(true);

            grid.add(Rules_leftbtn, 4, 3, 1, 1);
            grid.add(Rules_rightbtn, 4, 4, 1, 1);
            grid.add(goBack, 4, 5, 1, 1);


        });
        goBack.setOnAction(event -> {
            CurrentPage = TrackPageBeforeMovingToRules;
            Rules_leftbtn.setVisible(false);
            Rules_rightbtn.setVisible(false);
            drawSelectingPlayerAndClassesPage(gc);
            if (TrackPageBeforeMovingToRules == clickToPlay_Page) {
                drawClickToPlayPage(gc);
            }
            if (TrackPageBeforeMovingToRules == selectClass_Page) {
                if (Player1Class_CB.getSelectionModel().getSelectedItem() != null) {
                    drawPlayerClasses(gc, 1, Player1_Class);
                }
                if (Player2Class_CB.getSelectionModel().getSelectedItem() != null) {
                    drawPlayerClasses(gc, 2, Player2_Class);
                }
                if (Player3Class_CB.getSelectionModel().getSelectedItem() != null) {
                    drawPlayerClasses(gc, 3, Player3_Class);
                }
                if (Player4Class_CB.getSelectionModel().getSelectedItem() != null) {
                    drawPlayerClasses(gc, 4, Player4_Class);
                }
                if (Player5Class_CB.getSelectionModel().getSelectedItem() != null) {
                    drawPlayerClasses(gc, 5, Player5_Class);
                }
                if (Player6Class_CB.getSelectionModel().getSelectedItem() != null) {
                    drawPlayerClasses(gc, 6, Player6_Class);
                }

                Player1Class_CB.setVisible(true);
                Player2Class_CB.setVisible(true);
                Player3Class_CB.setVisible(true);
                Player4Class_CB.setVisible(true);
                Player5Class_CB.setVisible(true);
                Player6Class_CB.setVisible(true);

                player1_lbl.setVisible(true);
                player2_lbl.setVisible(true);
                player3_lbl.setVisible(true);
                player4_lbl.setVisible(true);
                player5_lbl.setVisible(true);
                player6_lbl.setVisible(true);

            }
            if (TrackPageBeforeMovingToRules == Play_Page) {
                verifyPlacement.setVisible(true);
                rotate_btn.setVisible(true);
                drawPlayPage(gc);
                drawRefBoardAgain();
            }
            goBack.setVisible(false);
        });
        Rules_leftbtn.setOnAction(event -> {
            if (WhichRulePage > 1) {
                WhichRulePage -= 1;
                drawRules(gc, getRulePage(WhichRulePage));
            }
        });
        Rules_rightbtn.setOnAction(event -> {
            if (WhichRulePage < 27) {
                WhichRulePage += 1;
                drawRules(gc, getRulePage(WhichRulePage));
            }
        });
        OnePlayer.setOnAction(event -> {
            NumOfPlayers = 1;
            System.out.println(NumOfPlayers);
        });
        TwoPlayer.setOnAction(event -> {
            NumOfPlayers = 2;
            System.out.println(NumOfPlayers);

        });
        ThreePlayer.setOnAction(event -> {
            NumOfPlayers = 3;
            System.out.println(NumOfPlayers);
        });
        FourPlayer.setOnAction(event -> {
            NumOfPlayers = 4;
            System.out.println(NumOfPlayers);
        });
        FivePlayer.setOnAction(event -> {
            NumOfPlayers = 5;
            System.out.println(NumOfPlayers);

        });
        SixPlayer.setOnAction(event -> {
            NumOfPlayers = 6;
            System.out.println(NumOfPlayers);
        });
        SevenPlayer.setOnAction(event -> {
            NumOfPlayers = 7;
            System.out.println(NumOfPlayers);
        });
        EightPlayer.setOnAction(event -> {
            NumOfPlayers = 8;
            System.out.println(NumOfPlayers);

        });
        NinePlayer.setOnAction(event -> {
            NumOfPlayers = 9;
            System.out.println(NumOfPlayers);

        });
        TenPlayer.setOnAction(event -> {
            NumOfPlayers = 10;
            System.out.println(NumOfPlayers);
        });
        canvas.setOnMouseClicked(event -> {
            double x = event.getX();
            double y = event.getY();
            if (CurrentPage == selectClass_Page) {
                if (count == 1 && playersDoneSelecting == true)
                {
                    CurrentPage = Play_Page;
                    drawPlayPage(gc);
                }
            }
            if (CurrentPage == clickToPlay_Page) {
                if (count == 0 && NumOfPlayers > 0) {
                    CurrentPage = selectClass_Page;
                    drawSelectingPlayerAndClassesPage(gc);
                    AddToPlayerClasses(Player1Class_CB);
                    AddToPlayerClasses(Player2Class_CB);
                    AddToPlayerClasses(Player3Class_CB);
                    AddToPlayerClasses(Player4Class_CB);
                    AddToPlayerClasses(Player5Class_CB);
                    AddToPlayerClasses(Player6Class_CB);

                    if (NumOfPlayers == 1) {
                        grid.add(player1_lbl, 12, 0, 1, 1);
                        grid.add(Player1Class_CB, 12, 1, 1, 1);
                    }
                    if (NumOfPlayers == 2) {
                        grid.add(player1_lbl, 11, 0, 1, 1);
                        grid.add(Player1Class_CB, 11, 1, 1, 1);
                        grid.add(player2_lbl, 11, 2, 1, 1);
                        grid.add(Player2Class_CB, 11, 3, 1, 1);
                    }
                    if (NumOfPlayers == 3) {
                        grid.add(player1_lbl, 11, 0, 1, 1);
                        grid.add(Player1Class_CB, 11, 1, 1, 1);
                        grid.add(player2_lbl, 11, 2, 1, 1);
                        grid.add(Player2Class_CB, 11, 3, 1, 1);
                        grid.add(player3_lbl, 11, 4, 1, 1);
                        grid.add(Player3Class_CB, 11, 5, 1, 1);
                    }
                    if (NumOfPlayers == 4) {
                        grid.add(player1_lbl, 11, 0, 1, 1);
                        grid.add(Player1Class_CB, 11, 1, 1, 1);
                        grid.add(player2_lbl, 11, 2, 1, 1);
                        grid.add(Player2Class_CB, 11, 3, 1, 1);
                        grid.add(player3_lbl, 11, 4, 1, 1);
                        grid.add(Player3Class_CB, 11, 5, 1, 1);
                        grid.add(player4_lbl, 11, 6, 1, 1);
                        grid.add(Player4Class_CB, 11, 7, 1, 1);
                    }
                    if (NumOfPlayers == 5) {
                        grid.add(player1_lbl, 11, 0, 1, 1);
                        grid.add(Player1Class_CB, 11, 1, 1, 1);
                        grid.add(player2_lbl, 11, 2, 1, 1);
                        grid.add(Player2Class_CB, 11, 3, 1, 1);
                        grid.add(player3_lbl, 11, 4, 1, 1);
                        grid.add(Player3Class_CB, 11, 5, 1, 1);
                        grid.add(player4_lbl, 11, 6, 1, 1);
                        grid.add(Player4Class_CB, 11, 7, 1, 1);
                        grid.add(player5_lbl, 11, 8, 1, 1);
                        grid.add(Player5Class_CB, 11, 9, 1, 1);
                    }
                    if (NumOfPlayers == 6) {
                        grid.add(player1_lbl, 11, 0, 1, 1);
                        grid.add(Player1Class_CB, 11, 1, 1, 1);
                        grid.add(player2_lbl, 11, 2, 1, 1);
                        grid.add(Player2Class_CB, 11, 3, 1, 1);
                        grid.add(player3_lbl, 11, 4, 1, 1);
                        grid.add(Player3Class_CB, 11, 5, 1, 1);
                        grid.add(player4_lbl, 11, 6, 1, 1);
                        grid.add(Player4Class_CB, 11, 7, 1, 1);
                        grid.add(player5_lbl, 11, 8, 1, 1);
                        grid.add(Player5Class_CB, 11, 9, 1, 1);
                        grid.add(player6_lbl, 11, 10, 1, 1);
                        grid.add(Player6Class_CB, 11, 11, 1, 1);
                    }
                    count++;
                }

            }

            if (CurrentPage == Play_Page) {
                if (clickedOnChamberCardStack == true ) {
                    FillEmptySpace();
                    int[] rowAndCol = {getRowAndCol(x,y)[0],getRowAndCol(x,y)[1]};
                    ArrayList<int[]> placements = getAvailablePlacements();
                    for (int[] t:placements) {
                        System.out.println(t[0]+" "+ t[1]);
                    }
                    System.out.println(getAvailablePlacements().contains(rowAndCol));
                    System.out.println(rowAndCol[0]+" "+rowAndCol[1]);

                    boolean check = false;
                    for (int[] t:placements) {
                        if(t[0]==rowAndCol[0])
                        {
                            if(t[1]==rowAndCol[1])
                            {
                                check=true;
                            }
                        }

                    }
                    if(refGrid[getRowAndCol(x, y)[0]][getRowAndCol(x, y)[1]]==null && check==true) {
                            clickedOnChamberCardStack = false;
                            highlightCard(gc, getRowAndCol(x, y)[0], getRowAndCol(x, y)[1]);
                        }


                    rotate_btn.setOnMouseClicked(event1 -> {
                        Image LOC = stringToImage(stackOfChamberTiles.get(0));

                        ImageView iv = new ImageView(LOC);
                        iv.setRotate(90);

                        SnapshotParameters params = new SnapshotParameters();
                        params.setFill(Color.TRANSPARENT);

                        Image rotatedImage = iv.snapshot(params, null);
                        setRotateImage(rotatedImage);
                        rotateDoorPlacement();
                        drawCardToTheSideForPlacement(gc);
                    });
                    boolean finalCheck = check;
                    verifyPlacement.setOnMouseClicked(e -> {
                        if(stackOfChamberTiles.size()>0 && refGrid[getRowAndCol(x, y)[0]][getRowAndCol(x, y)[1]]==null && finalCheck && VerifyIfDoorsConnect(getRowAndCol(x,y)[0],getRowAndCol(x,y)[1]))
                        {
                            drawCardOnBoard(gc, stringToImage(stackOfChamberTiles.get(0)), getRowAndCol(x, y)[0], getRowAndCol(x, y)[1]);
                            refGrid[getRowAndCol(x, y)[0]][getRowAndCol(x, y)[1]] = stackOfChamberTiles.get(0);
                            System.out.println(stackOfChamberTiles.get(0));
                            stackOfChamberTiles.remove(0);
                            gc.setFill(Color.GRAY);
                            gc.fillRect((10 + Outline.getWidth() + 20) + (tileLengths) + 20, 20, 200, 200);
                        }
                    });
                }
                if (clickedOnChamberCardStack == false) {
                    if (event.getX() > 10 + Outline.getWidth() + 20 && event.getY() > 10 + 20) {
                        if (event.getX() < (10 + Outline.getWidth() + 20) + (tileLengths) && event.getY() < 10 + 20 + tileLengths) {
                            clickedOnChamberCardStack = true;
                            drawCardToTheSideForPlacement(gc);

                        }
                    }
                }
            }

            if (CurrentPage == Play_Page) {
                grid.add(verifyPlacement, 4, 1, 1, 1);
                grid.add(rotate_btn, 4, 2, 1, 1);
            }


        });
        Player1Class_CB.setOnAction(event -> {
            Player1_Class = Player1Class_CB.getSelectionModel().getSelectedItem();
            drawPlayerClasses(gc, 1, Player1_Class);

            if (NumOfPlayers == 1) {
                if (Player1_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 2) {
                if (Player1_Class != "" && Player2_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 3) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 4) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "" && Player4_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 5) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "" && Player4_Class != "" && Player5_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 6) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "" && Player4_Class != "" && Player5_Class != "" && Player6_Class != "")
                    playersDoneSelecting = true;
            }
        });
        Player2Class_CB.setOnAction(event -> {
            Player2_Class = Player2Class_CB.getSelectionModel().getSelectedItem();
            drawPlayerClasses(gc, 2, Player2_Class);
            if (NumOfPlayers == 1) {
                if (Player1_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 2) {
                if (Player1_Class != "" && Player2_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 3) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 4) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "" && Player4_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 5) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "" && Player4_Class != "" && Player5_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 6) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "" && Player4_Class != "" && Player5_Class != "" && Player6_Class != "")
                    playersDoneSelecting = true;
            }
        });
        Player3Class_CB.setOnAction(event -> {
            Player3_Class = Player3Class_CB.getSelectionModel().getSelectedItem();
            drawPlayerClasses(gc, 3, Player3_Class);
            if (NumOfPlayers == 1) {
                if (Player1_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 2) {
                if (Player1_Class != "" && Player2_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 3) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 4) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "" && Player4_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 5) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "" && Player4_Class != "" && Player5_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 6) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "" && Player4_Class != "" && Player5_Class != "" && Player6_Class != "")
                    playersDoneSelecting = true;
            }
        });
        Player4Class_CB.setOnAction(event -> {
            Player4_Class = Player4Class_CB.getSelectionModel().getSelectedItem();
            drawPlayerClasses(gc, 4, Player4_Class);
            if (NumOfPlayers == 1) {
                if (Player1_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 2) {
                if (Player1_Class != "" && Player2_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 3) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 4) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "" && Player4_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 5) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "" && Player4_Class != "" && Player5_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 6) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "" && Player4_Class != "" && Player5_Class != "" && Player6_Class != "")
                    playersDoneSelecting = true;
            }
        });
        Player5Class_CB.setOnAction(event -> {
            Player5_Class = Player5Class_CB.getSelectionModel().getSelectedItem();
            drawPlayerClasses(gc, 5, Player5_Class);
            if (NumOfPlayers == 1) {
                if (Player1_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 2) {
                if (Player1_Class != "" && Player2_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 3) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 4) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "" && Player4_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 5) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "" && Player4_Class != "" && Player5_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 6) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "" && Player4_Class != "" && Player5_Class != "" && Player6_Class != "")
                    playersDoneSelecting = true;
            }
        });
        Player6Class_CB.setOnAction(event -> {
            Player6_Class = Player6Class_CB.getSelectionModel().getSelectedItem();
            drawPlayerClasses(gc, 6, Player6_Class);
            if (NumOfPlayers == 1) {
                if (Player1_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 2) {
                if (Player1_Class != "" && Player2_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 3) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 4) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "" && Player4_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 5) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "" && Player4_Class != "" && Player5_Class != "")
                    playersDoneSelecting = true;
            }
            if (NumOfPlayers == 6) {
                if (Player1_Class != "" && Player2_Class != "" && Player3_Class != "" && Player4_Class != "" && Player5_Class != "" && Player6_Class != "")
                    playersDoneSelecting = true;
            }
        });
        Scene scene = new Scene(group);
        canvas.requestFocus();
        primaryStage.setScene(scene);
        // draw(canvas.getGraphicsContext2D());
        primaryStage.show();
    }

    public void drawRefBoardAgain()
    {
        for (int r = 0; r < refGrid.length; r++) {
            for (int c = 0; c < refGrid[0].length; c++) {
                if(refGrid[r][c]!=null)
                {
                    gc.drawImage(stringToImage(refGrid[r][c]),10+25+((c)*tileLengths), 10+25+((r)*tileLengths),tileLengths,tileLengths);
                }
            }
        }

    }
    public boolean VerifyIfDoorsConnect(int locR,int locC)
    {
        int[] loc = {locR,locC};
        for (int r = 0; r < refGrid.length ; r++) {
            for (int c = 0; c < refGrid[0].length; c++) {
                if(refGrid[r][c]!=null)
                {
                    int[] locOfPieceOnBoard = {r,c};
                    int[] locOfPieceOnBoardUpOne = {locOfPieceOnBoard[0]-1, locOfPieceOnBoard[1]};
                    int[] locOfPieceOnBoardDownOne = {locOfPieceOnBoard[0]+1, locOfPieceOnBoard[1]};
                    int[] locOfPieceOnBoardRightOne = {locOfPieceOnBoard[0], locOfPieceOnBoard[1]+1};
                    int[] locOfPieceOnBoardLeftOne = {locOfPieceOnBoard[0], locOfPieceOnBoard[1]-1};
                    if(refGrid[r][c]=="AcidJets")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            if(AcidJets_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }
                            if(AcidJets_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }

                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(AcidJets_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(AcidJets_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(AcidJets_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(AcidJets_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(AcidJets_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(AcidJets_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="ArrowTraps")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(ArrowTraps_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(ArrowTraps_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }

                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(ArrowTraps_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(ArrowTraps_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(ArrowTraps_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(ArrowTraps_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(ArrowTraps_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(ArrowTraps_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="DarkSlime")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(DarkSlime_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(DarkSlime_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }

                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(DarkSlime_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(DarkSlime_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(DarkSlime_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(DarkSlime_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(DarkSlime_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(DarkSlime_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="DenOfSnakes")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(DenOfSnakes_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(DenOfSnakes_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }

                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(DenOfSnakes_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(DenOfSnakes_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(DenOfSnakes_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(DenOfSnakes_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(DenOfSnakes_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(DenOfSnakes_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="Dragonling")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(Dragonling_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(Dragonling_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(Dragonling_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(Dragonling_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(Dragonling_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(Dragonling_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(Dragonling_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(Dragonling_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="FelKnight")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(FelKnight_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(FelKnight_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(FelKnight_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(FelKnight_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(FelKnight_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(FelKnight_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(FelKnight_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(FelKnight_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="FireOfEidolon")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(FireOfEidolon_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(FireOfEidolon_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(FireOfEidolon_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(FireOfEidolon_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(FireOfEidolon_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(FireOfEidolon_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(FireOfEidolon_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(FireOfEidolon_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="FloatingStones")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(FloatingStones_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(FloatingStones_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(FloatingStones_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(FloatingStones_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(FloatingStones_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(FloatingStones_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(FloatingStones_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(FloatingStones_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="HallOfIllusion")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(HallOfIllusion_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(HallOfIllusion_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(HallOfIllusion_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(HallOfIllusion_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(HallOfIllusion_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(HallOfIllusion_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(HallOfIllusion_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(HallOfIllusion_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="LaughingShadow")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(LaughingShadow_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(LaughingShadow_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(LaughingShadow_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(LaughingShadow_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(LaughingShadow_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(LaughingShadow_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(LaughingShadow_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(LaughingShadow_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="LavaLake")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(LavaLake_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(LavaLake_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(LavaLake_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(LavaLake_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(LavaLake_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(LavaLake_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(LavaLake_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(LavaLake_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="MimicChest")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(MimicChest_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(MimicChest_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(MimicChest_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(MimicChest_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(MimicChest_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(MimicChest_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(MimicChest_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(MimicChest_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="MindEater")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(MindEater_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(MindEater_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(MindEater_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(MindEater_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(MindEater_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(MindEater_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(MindEater_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(MindEater_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="Minotaur")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(Minotaur_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(Minotaur_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(Minotaur_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(Minotaur_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(Minotaur_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(Minotaur_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(Minotaur_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(Minotaur_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="NewExit")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(NewExit_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(NewExit_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(NewExit_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(NewExit_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(NewExit_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(NewExit_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(NewExit_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(NewExit_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="OgreBrute")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(OgreBrute_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(OgreBrute_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(OgreBrute_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(OgreBrute_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(OgreBrute_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(OgreBrute_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(OgreBrute_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(OgreBrute_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="ParadoxPuzzle")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(ParadoxPuzzle_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(ParadoxPuzzle_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(ParadoxPuzzle_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(ParadoxPuzzle_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(ParadoxPuzzle_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(ParadoxPuzzle_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(ParadoxPuzzle_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(ParadoxPuzzle_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="PendulumBlades")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(PendulumBlades_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(PendulumBlades_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(PendulumBlades_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(PendulumBlades_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(PendulumBlades_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(PendulumBlades_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(PendulumBlades_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(PendulumBlades_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="Psychomancer")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(Psychomancer_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(Psychomancer_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(Psychomancer_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(Psychomancer_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(Psychomancer_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(Psychomancer_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(Psychomancer_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(Psychomancer_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="SecretPassageX")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(SecretPassageX_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(SecretPassageX_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(SecretPassageX_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(SecretPassageX_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(SecretPassageX_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(SecretPassageX_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(SecretPassageX_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(SecretPassageX_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="SecretPassageY")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(SecretPassageX_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(SecretPassageY_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(SecretPassageX_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(SecretPassageY_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(SecretPassageX_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(SecretPassageY_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(SecretPassageX_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(SecretPassageY_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="SkeletalGuards")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(SkeletalGuards_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(SkeletalGuards_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(SkeletalGuards_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(SkeletalGuards_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(SkeletalGuards_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(SkeletalGuards_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(SkeletalGuards_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(SkeletalGuards_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="SphynxsRiddle")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            /*if(SphynxsRiddle_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(SphynxsRiddle_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(SphynxsRiddle_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(SphynxsRiddle_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(SphynxsRiddle_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(SphynxsRiddle_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(SphynxsRiddle_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(SphynxsRiddle_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="SpikedPit")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            //->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                            /*if(SpikedPit_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(SpikedPit_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(SpikedPit_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(SpikedPit_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(SpikedPit_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(SpikedPit_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(SpikedPit_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(SpikedPit_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="Vestibule")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            //->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                            /*if(Vestibule_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            System.out.println("Vestibule_doorplacements.contains(\"up\")==true"+ (Vestibule_doorplacements.contains("up")==true));
                            System.out.println("stringToDoorPlacement(stackOfChamberTiles.get(0)).contains(\"down\")==true"+ (stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true));
                            if(Vestibule_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            System.out.println(Vestibule_doorplacements.toString());
                            System.out.println(stringToDoorPlacement(stackOfChamberTiles.get(0)).toString());
                            /*if(Vestibule_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(Vestibule_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(Vestibule_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(Vestibule_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(Vestibule_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(Vestibule_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="VoraciousPlant")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            //->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                            /*if(VoraciousPlant_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(VoraciousPlant_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(VoraciousPlant_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(VoraciousPlant_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(VoraciousPlant_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(VoraciousPlant_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(VoraciousPlant_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(VoraciousPlant_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="VoraxsFocus")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            //->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                            /*if(VoraxsFocus_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(VoraxsFocus_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(VoraxsFocus_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(VoraxsFocus_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(VoraxsFocus_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(VoraxsFocus_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(VoraxsFocus_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(VoraxsFocus_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="VoraxsHeart")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            //->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                            /*if(VoraxsHeart_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(VoraxsHeart_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(VoraxsHeart_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(VoraxsHeart_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(VoraxsHeart_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(VoraxsHeart_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(VoraxsHeart_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(VoraxsHeart_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                    if(refGrid[r][c]=="VoraxsKnowledge")
                    {
                        if((loc[0] == locOfPieceOnBoardUpOne[0] && loc[1] == locOfPieceOnBoardUpOne[1]))
                        {
                            //->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                            /*if(VoraxsKnowledge_doorplacements.contains("up")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")!=true)
                            {
                                return false;
                            }*/
                            if(VoraxsKnowledge_doorplacements.contains("up")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("down")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardDownOne[0] && loc[1] == locOfPieceOnBoardDownOne[1]))
                        {
                            /*if(VoraxsKnowledge_doorplacements.contains("down")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")!=true)
                            {
                                return false;
                            }*/
                            if(VoraxsKnowledge_doorplacements.contains("down")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("up")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardRightOne[0] && loc[1] == locOfPieceOnBoardRightOne[1]))
                        {
                            /*if(VoraxsKnowledge_doorplacements.contains("right")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")!=true)
                            {
                                return false;
                            }*/
                            if(VoraxsKnowledge_doorplacements.contains("right")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("left")==true)
                            {
                                return true;
                            }
                        }
                        if((loc[0] == locOfPieceOnBoardLeftOne[0] && loc[1] == locOfPieceOnBoardLeftOne[1]))
                        {
                            /*if(VoraxsKnowledge_doorplacements.contains("left")!=true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")!=true)
                            {
                                return false;
                            }*/
                            if(VoraxsKnowledge_doorplacements.contains("left")==true && stringToDoorPlacement(stackOfChamberTiles.get(0)).contains("right")==true)
                            {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public ArrayList<String> stringToDoorPlacement(String room)
    {
        if("AcidJets".equals(room)) {
            return AcidJets_doorplacements;
        }
        if("ArrowTraps".equals(room)) {
            return ArrowTraps_doorplacements;
        }
        if("Blank".equals(room)) {
            return Blank_doorplacements;
        }
        if("DarkSlime".equals(room)) {
            return DarkSlime_doorplacements;
        }
        if("DenOfSnakes".equals(room)) {
            return DenOfSnakes_doorplacements;
        }
        if("Dragonling".equals(room)) {
            return Dragonling_doorplacements;
        }
        if("FelKnight".equals(room)) {
            return FelKnight_doorplacements;
        }
        if("FireOfEidolon".equals(room)) {
            return FireOfEidolon_doorplacements;
        }
        if("FloatingStones".equals(room)) {
            return FloatingStones_doorplacements;
        }
        if("HallOfIllusion".equals(room)) {
            return HallOfIllusion_doorplacements;
        }
        if("LaughingShadow".equals(room)) {
            return LaughingShadow_doorplacements;
        }
        if("LavaLake".equals(room)) {
            return LavaLake_doorplacements;
        }
        if("MimicChest".equals(room)) {
            return MimicChest_doorplacements;
        }
        if("MindEater".equals(room)) {
            return MindEater_doorplacements;
        }
        if("Minotaur".equals(room)) {
            return Minotaur_doorplacements;
        }
        if("NewExit".equals(room)) {
            return NewExit_doorplacements;
        }
        if("OgreBrute".equals(room)) {
            return OgreBrute_doorplacements;
        }
        if("ParadoxPuzzle".equals(room)) {
            return ParadoxPuzzle_doorplacements;
        }
        if("PendulumBlades" .equals(room)) {
            return PendulumBlades_doorplacements;
        }
        if("Psychomancer".equals(room)) {
            return Psychomancer_doorplacements;
        }
        if("SecretPassageX".equals(room)) {
            return SecretPassageX_doorplacements;
        }
        if("SecretPassageY".equals(room)) {
            return SecretPassageY_doorplacements;
        }
        if("SkeletalGuards".equals(room)) {
            return SkeletalGuards_doorplacements;
        }
        if("SphynxsRiddle".equals(room)) {
            return SphynxsRiddle_doorplacements;
        }
        if("SpikedPit".equals(room)) {
            return SpikedPit_doorplacements;
        }
        if("Vestibule".equals(room)) {
            return Vestibule_doorplacements;
        }
        if("VoraciousPlant".equals(room)) {
            return VoraciousPlant_doorplacements;
        }
        if("VoraxsFocus".equals(room)) {
            return VoraxsFocus_doorplacements;
        }
        if("VoraxsHeart".equals(room)) {
            return VoraxsHeart_doorplacements;
        }
        if("VoraxsKnowledge".equals(room)) {
            return VoraxsKnowledge_doorplacements;
        }
        return null;
    }

    public void rotateDoorPlacement()
    {
        //Clockwise
        if("AcidJets"== stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)AcidJets_doorplacements.clone();
                if (ChamberCopy.indexOf("up") != -1) {
                AcidJets_doorplacements.set(ChamberCopy.indexOf("up"),"right");
            }
            if(ChamberCopy.indexOf("down") != -1)
            {
                AcidJets_doorplacements.set(ChamberCopy.indexOf("down"),"left");
            }
            if(ChamberCopy.indexOf("right") != -1)
            {
                AcidJets_doorplacements.set(ChamberCopy.indexOf("right"),"down");
            }
            if(ChamberCopy.indexOf("left") != -1)
            {
                AcidJets_doorplacements.set(ChamberCopy.indexOf("left"),"up");
            }
        }
        if("ArrowTraps"== stackOfChamberTiles.get(0))
        {
            ArrayList<String> ChamberCopy = (ArrayList<String>)ArrowTraps_doorplacements.clone();

            if (ChamberCopy.indexOf("up") != -1) {
                ArrowTraps_doorplacements.set(ChamberCopy.indexOf("up"),"right");
            }
            if(ChamberCopy.indexOf("down") != -1)
            {
                ArrowTraps_doorplacements.set(ChamberCopy.indexOf("down"),"left");
            }
            if(ChamberCopy.indexOf("right") != -1)
            {
                ArrowTraps_doorplacements.set(ChamberCopy.indexOf("right"),"down");
            }
            if(ChamberCopy.indexOf("left") != -1)
            {
                ArrowTraps_doorplacements.set(ChamberCopy.indexOf("left"),"up");
            }
        }
        if("Blank"== stackOfChamberTiles.get(0))
        {
            ArrayList<String> ChamberCopy = (ArrayList<String>)Blank_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                Blank_doorplacements.set(ChamberCopy.indexOf("up"),"right");
            }
            if(ChamberCopy.indexOf("down") != -1)
            {
                Blank_doorplacements.set(ChamberCopy.indexOf("down"),"left");
            }
            if(ChamberCopy.indexOf("right") != -1)
            {
                Blank_doorplacements.set(ChamberCopy.indexOf("right"),"down");
            }
            if(ChamberCopy.indexOf("left") != -1)
            {
                Blank_doorplacements.set(ChamberCopy.indexOf("left"),"up");
            }
        }
        if("DarkSlime" == stackOfChamberTiles.get(0))
        {
            ArrayList<String> ChamberCopy = (ArrayList<String>)DarkSlime_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                DarkSlime_doorplacements.set(ChamberCopy.indexOf("up"),"right");
            }
            if(ChamberCopy.indexOf("down") != -1)
            {
                DarkSlime_doorplacements.set(ChamberCopy.indexOf("down"),"left");
            }
            if(ChamberCopy.indexOf("right") != -1)
            {
                DarkSlime_doorplacements.set(ChamberCopy.indexOf("right"),"down");
            }
            if(ChamberCopy.indexOf("left") != -1)
            {
                DarkSlime_doorplacements.set(ChamberCopy.indexOf("left"),"up");
            }
        }
        if("DenOfSnakes" == stackOfChamberTiles.get(0))
        {
            ArrayList<String> ChamberCopy = (ArrayList<String>)DenOfSnakes_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                DenOfSnakes_doorplacements.set(ChamberCopy.indexOf("up"),"right");
            }
            if(ChamberCopy.indexOf("down") != -1)
            {
                DenOfSnakes_doorplacements.set(ChamberCopy.indexOf("down"),"left");
            }
            if(ChamberCopy.indexOf("right") != -1)
            {
                DenOfSnakes_doorplacements.set(ChamberCopy.indexOf("right"),"down");
            }
            if(ChamberCopy.indexOf("left") != -1)
            {
                DenOfSnakes_doorplacements.set(ChamberCopy.indexOf("left"),"up");
            }
        }
        if("Dragonling"  == stackOfChamberTiles.get(0))
        {
            ArrayList<String> ChamberCopy = (ArrayList<String>)Dragonling_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                Dragonling_doorplacements.set(ChamberCopy.indexOf("up"),"right");
            }
            if(ChamberCopy.indexOf("down") != -1)
            {
                Dragonling_doorplacements.set(ChamberCopy.indexOf("down"),"left");
            }
            if(ChamberCopy.indexOf("right") != -1)
            {
                Dragonling_doorplacements.set(ChamberCopy.indexOf("right"),"down");
            }
            if(ChamberCopy.indexOf("left") != -1)
            {
                Dragonling_doorplacements.set(ChamberCopy.indexOf("left"),"up");
            }
        }
        if("FelKnight"== stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)FelKnight_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                FelKnight_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                FelKnight_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                FelKnight_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                FelKnight_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }
        }

        if("FireOfEidolon"  == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)FireOfEidolon_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                FireOfEidolon_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                FireOfEidolon_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            };
            if (ChamberCopy.indexOf("down") != -1) {
                FireOfEidolon_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                FireOfEidolon_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }
        }
        if("FloatingStones" == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)FloatingStones_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                FloatingStones_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                FloatingStones_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                FloatingStones_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                FloatingStones_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }        }

        if("HallOfIllusion" == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)HallOfIllusion_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                HallOfIllusion_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                HallOfIllusion_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                HallOfIllusion_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                HallOfIllusion_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }        }

        if("LaughingShadow" == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)LaughingShadow_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                LaughingShadow_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                LaughingShadow_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                LaughingShadow_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                LaughingShadow_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }        }

        if("LavaLake"       == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)LavaLake_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1)
            {
                LavaLake_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1)
            {
                LavaLake_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1)
            {
                LavaLake_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1)
            {
                LavaLake_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }
        }

        if("MimicChest"     == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)MimicChest_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                MimicChest_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                MimicChest_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                MimicChest_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                MimicChest_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }
        }

        if("MindEater"      == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)MindEater_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                MindEater_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                MindEater_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                MindEater_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                MindEater_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }
        }

        if("Minotaur"       == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)Minotaur_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                Minotaur_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                Minotaur_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                Minotaur_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                Minotaur_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }
        }

        if("NewExit"        == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)NewExit_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                NewExit_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                NewExit_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                NewExit_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                NewExit_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            } }

        if("OgreBrute"      == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)OgreBrute_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                OgreBrute_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                OgreBrute_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                OgreBrute_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                OgreBrute_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }   }

        if("ParadoxPuzzle"  == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)ParadoxPuzzle_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                ParadoxPuzzle_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                ParadoxPuzzle_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                ParadoxPuzzle_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                ParadoxPuzzle_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }
        }

        if("PendulumBlades" == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)PendulumBlades_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                PendulumBlades_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                PendulumBlades_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                PendulumBlades_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                PendulumBlades_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }        }

        if("Psychomancer"   == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)Psychomancer_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                Psychomancer_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                Psychomancer_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                Psychomancer_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                Psychomancer_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }
        }

        if("SecretPassageX" == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)SecretPassageX_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                SecretPassageX_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                SecretPassageX_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                SecretPassageX_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            };
            if (ChamberCopy.indexOf("left") != -1) {
                SecretPassageX_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }
        }

        if("SecretPassageY" == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)SecretPassageY_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                SecretPassageY_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                SecretPassageY_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                SecretPassageY_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                SecretPassageY_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }
        }

        if("SkeletalGuards" == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)SkeletalGuards_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                SkeletalGuards_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                SkeletalGuards_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                SkeletalGuards_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                SkeletalGuards_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }
        }

        if("SphynxsRiddle"  == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)SphynxsRiddle_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                SphynxsRiddle_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                SphynxsRiddle_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                SphynxsRiddle_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                SphynxsRiddle_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }
        }

        if("SpikedPit"  == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)SpikedPit_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                SpikedPit_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                SpikedPit_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                SpikedPit_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                SpikedPit_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }
        }

        if("VoraciousPlant" == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)VoraciousPlant_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                VoraciousPlant_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                VoraciousPlant_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                VoraciousPlant_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            };
            if (ChamberCopy.indexOf("left") != -1) {
                VoraciousPlant_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }
        }

        if("VoraxsFocus"    == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)VoraxsFocus_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                VoraxsFocus_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                VoraxsFocus_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                VoraxsFocus_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                VoraxsFocus_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }
        }

        if("VoraxsHeart"    == stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)VoraxsHeart_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                VoraxsHeart_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                VoraxsHeart_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                VoraxsHeart_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                VoraxsHeart_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }
        }

        if("VoraxsKnowledge"== stackOfChamberTiles.get(0)) {
            ArrayList<String> ChamberCopy = (ArrayList<String>)VoraxsKnowledge_doorplacements.clone();
            if (ChamberCopy.indexOf("up") != -1) {
                VoraxsKnowledge_doorplacements.set(ChamberCopy.indexOf("up"), "right");
            }
            if (ChamberCopy.indexOf("right") != -1) {
                VoraxsKnowledge_doorplacements.set(ChamberCopy.indexOf("right"), "down");
            }
            if (ChamberCopy.indexOf("down") != -1) {
                VoraxsKnowledge_doorplacements.set(ChamberCopy.indexOf("down"), "left");
            }
            if (ChamberCopy.indexOf("left") != -1) {
                VoraxsKnowledge_doorplacements.set(ChamberCopy.indexOf("left"), "up");
            }
        }
    }

    public void FillEmptySpace()
    {
        gc.setFill(Color.GRAY);
        for (int r = 0; r <9; r++) {
            for (int c = 0; c <9; c++) {
                if(refGrid[r][c]==null)
                {
                    gc.fillRect(10+25+((c)*tileLengths), 10+25+((r)*tileLengths),tileLengths,tileLengths);
                }
            }
        }
        gc.setStroke(Color.WHITE);
        for (int r = 0; r <9; r++) {
            for (int c = 0; c <9; c++) {

                    gc.strokeRect(10+25+((c)*tileLengths), 10+25+((r)*tileLengths),tileLengths,tileLengths);
            }
        }
    }
    public ArrayList<int[]> getAvailablePlacements()
    {
        ArrayList<int[]> placements = new ArrayList<>();
        for (int r = 0; r < refGrid.length; r++) {
            for (int c = 0; c < refGrid[0].length; c++) {
                if(refGrid[r][c]!=null)
                {
                    //up
                    if((r-1>=0 && r-1<=8) && refGrid[r-1][c]==null)
                    {
                        int[] place = {r-1,c};
                        placements.add(place);
                    }
                    //down
                    if((r+1>=0 && r+1<=8) && refGrid[r+1][c]==null)
                    {
                        int[] place = {r+1,c};
                        placements.add(place);
                    }
                    //left
                    if((c-1>=0 && c-1<=8) && refGrid[r][c-1]==null)
                    {
                        int[] place = {r,c-1};
                        placements.add(place);
                    }
                    //right
                    if((c+1>=0 && c+1<=8) && refGrid[r][c+1]==null)
                    {
                        int[] place = {r,c+1};
                        placements.add(place);
                    }
                }

            }
        }
        return placements;
    }
    public Image getRulePage(int i) {
        if (i == 1) {
            return One;
        }
        if (i == 2) {
            return Two;
        }
        if (i == 3) {
            return Three;
        }
        if (i == 4) {
            return Four;
        }
        if (i == 5) {
            return Five;
        }
        if (i == 6) {
            return Six;
        }
        if (i == 7) {
            return Seven;
        }
        if (i == 8) {
            return Eight;
        }
        if (i == 9) {
            return Nine;
        }
        if (i == 10) {
            return Ten;
        }
        if (i == 11) {
            return Eleven;
        }
        if (i == 12) {
            return Twelve;
        }
        if (i == 13) {
            return Thirteen;
        }
        if (i == 14) {
            return Fourteen;
        }
        if (i == 15) {
            return Fifteen;
        }
        if (i == 16) {
            return Sixteen;
        }
        if (i == 17) {
            return Seventeen;
        }
        if (i == 18) {
            return Eighteen;
        }
        if (i == 19) {
            return Nineteen;
        }
        if (i == 20) {
            return Twenty;
        }
        if (i == 21) {
            return Twentyone;
        }
        if (i == 22) {
            return Twentytwo;
        }
        if (i == 23) {
            return Twentythree;
        }
        if (i == 24) {
            return Twentyfour;
        }
        if (i == 25) {
            return Twentyfive;
        }
        if (i == 26) {
            return Twentysix;
        }
        return null;

    }

    public void setRotateImage(Image RotatedImage)
    {
        if(Vestibule_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            Vestibule_img = RotatedImage;
        }
        if(AcidJets_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            AcidJets_img = RotatedImage;
        }
        if(ArrowTraps_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            ArrowTraps_img= RotatedImage;
        }
        if(Blank_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            Blank_img= RotatedImage;
        }
        if(DarkSlime_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            DarkSlime_img= RotatedImage;
        }
        if(DenOfSnakes_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            DenOfSnakes_img= RotatedImage;
        }
        if(Dragonling_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            Dragonling_img= RotatedImage;
        }
        if(FelKnight_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            FelKnight_img= RotatedImage;
        }
        if(FireOfEidolon_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            FireOfEidolon_img= RotatedImage;
        }
        if(FloatingStones_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            FloatingStones_img= RotatedImage;
        }
        if(HallOfIllusion_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            HallOfIllusion_img= RotatedImage;
        }
        if(LaughingShadow_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            LaughingShadow_img= RotatedImage;
        }
        if(LavaLake_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            LavaLake_img= RotatedImage;
        }
        if(MimicChest_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            MimicChest_img= RotatedImage;
        }
        if(MindEater_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            MindEater_img= RotatedImage;
        }
        if(Minotaur_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            Minotaur_img= RotatedImage;
        }
        if(NewExit_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            NewExit_img= RotatedImage;
        }
        if(OgreBrute_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            OgreBrute_img= RotatedImage;
        }
        if(ParadoxPuzzle_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            ParadoxPuzzle_img= RotatedImage;
        }
        if(PendulumBlades_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            PendulumBlades_img= RotatedImage;
        }
        if(Psychomancer_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            Psychomancer_img= RotatedImage;
        }
        if(SecretPassageX_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            SecretPassageX_img= RotatedImage;
        }
        if(SecretPassageY_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            SecretPassageY_img= RotatedImage;
        }
        if(SkeletalGuards_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            SkeletalGuards_img= RotatedImage;
        }
        if(SphynxsRiddle_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            SphynxsRiddle_img= RotatedImage;
        }
        if(SpikedPit_img == (stringToImage(stackOfChamberTiles.get(0))))
        {
            SpikedPit_img = RotatedImage;
        }
        if(VoraciousPlant_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            VoraciousPlant_img= RotatedImage;
        }
        if(VoraxsFocus_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            VoraxsFocus_img= RotatedImage;
        }
        if(VoraxsHeart_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            VoraxsHeart_img= RotatedImage;
        }
        if(VoraxsKnowledge_img==(stringToImage(stackOfChamberTiles.get(0))))
        {
            VoraxsKnowledge_img= RotatedImage;
        }
    }


    public boolean checkifClickIsInOutline(double x, double y)
    {
        if(x>10+25+(0*tileLengths) && y>10+25+(0*tileLengths)) {
            if (x<10+25+(0*tileLengths)+tileLengths*9 && y<10+25+(0*tileLengths)+tileLengths*9)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    public int[] getRowAndCol(double x, double y)
    {
        int[] rowAndCol = new int[2];
        if(checkifClickIsInOutline(x,y)==true)
        {
            for (int r = 0; r < 9; r++) {
                for (int c = 0; c < 9; c++) {
                    if(x > 10+25+(c)*tileLengths && y>10+25+((r)*tileLengths))
                    {
                        if(x < 10+25+((c)*tileLengths)+tileLengths && y < 10+25+((r)*tileLengths)+tileLengths)
                        {
                            rowAndCol[0] = r;
                            rowAndCol[1] = c;
                            return rowAndCol;
                        }
                    }
                }
            }
            rowAndCol[0] = -1;
            rowAndCol[1] = -1;
            return rowAndCol;
        }
        else
            {
            rowAndCol[0] = -1;
            rowAndCol[1] = -1;
            return rowAndCol;
        }
    }

    public ArrayList<String> randomizeStack()
    {
        Collections.shuffle(stackOfChamberTiles);
        return stackOfChamberTiles;
    }

    public void AddToPlayerClasses(ComboBox<String> comboBox)
    {
        comboBox.getItems().addAll("Cleric","DarkKnight", "Engineer", "Geomancer", "Paladin", "Ranger" , "Rogue", "Sage", "Soldier", "Swordsman", "Warrior", "Wizard");
    }

    public void highlightCard(GraphicsContext g, int r, int c)
    {
        g.setFill(Color.YELLOW);
        g.fillRect(10+25+((c)*tileLengths),10+25+((r)*tileLengths),tileLengths,tileLengths);
    }

    public void drawRules(GraphicsContext g, Image rulePage)
    {
        g.setFill(Color.BLACK);
        g.fillRect(0,0,canvasWidth,canvasHeight);
        g.drawImage(rulePage,0,0,canvasWidth,canvasHeight);
    }

    public void drawPlayerClasses(GraphicsContext g, int player, String Card)
    {
        if(Card.equalsIgnoreCase("Cleric"))
        {
            g.drawImage(Cleric,25+(player-1)*tileLengths*2+10, 10+25+(OutlineHeight)+25,tileLengths*2,tileLengths*2);
        }
        if(Card.equalsIgnoreCase("DarkKnight"))
        {
            g.drawImage(DarkKnight,25+(player-1)*tileLengths*2+10, 10+25+(OutlineHeight)+25,tileLengths*2,tileLengths*2);
        }
        if(Card.equalsIgnoreCase("Engineer"))
        {
            g.drawImage(Engineer,25+(player-1)*tileLengths*2+10, 10+25+(OutlineHeight)+25,tileLengths*2,tileLengths*2);
        }
        if(Card.equalsIgnoreCase("Geomancer"))
        {
            g.drawImage(Geomancer,25+(player-1)*tileLengths*2+10, 10+25+(OutlineHeight)+25,tileLengths*2,tileLengths*2);
        }
        if(Card.equalsIgnoreCase("Paladin"))
        {
            g.drawImage(Paladin,25+(player-1)*tileLengths*2+10, 10+25+(OutlineHeight)+25,tileLengths*2,tileLengths*2);
        }
        if(Card.equalsIgnoreCase("Ranger"))
        {
            g.drawImage(Ranger,25+(player-1)*tileLengths*2+10, 10+25+(OutlineHeight)+25,tileLengths*2,tileLengths*2);
        }
        if(Card.equalsIgnoreCase("Rogue"))
        {
            g.drawImage(Rogue,25+(player-1)*tileLengths*2+10, 10+25+(OutlineHeight)+25,tileLengths*2,tileLengths*2);
        }
        if(Card.equalsIgnoreCase("Sage"))
        {
            g.drawImage(Sage,25+(player-1)*tileLengths*2+10, 10+25+(OutlineHeight)+25,tileLengths*2,tileLengths*2);
        }
        if(Card.equalsIgnoreCase("Soldier"))
        {
            g.drawImage(Soldier,25+(player-1)*tileLengths*2+10, 10+25+(OutlineHeight)+25,tileLengths*2,tileLengths*2);
        }
        if(Card.equalsIgnoreCase("Swordsman"))
        {
            g.drawImage(Swordsman,25+(player-1)*tileLengths*2+10, 10+25+(OutlineHeight)+25,tileLengths*2,tileLengths*2);
        }
        if(Card.equalsIgnoreCase("Warrior"))
        {
            g.drawImage(Warrior,25+(player-1)*tileLengths*2+10, 10+25+(OutlineHeight)+25,tileLengths*2,tileLengths*2);
        }
        if(Card.equalsIgnoreCase("Wizard"))
        {
            g.drawImage(Wizard,25+(player-1)*tileLengths*2+10, 10+25+(OutlineHeight)+25,tileLengths*2,tileLengths*2);
        }
    }

    public void drawCardToTheSideForPlacement(GraphicsContext g)
    {
            Image card_img = stringToImage(stackOfChamberTiles.get(0));
            g.drawImage(card_img, (10 + Outline.getWidth() + 20) + (tileLengths) + 20, 20, 200, 200);
    }
    public void drawCardOnBoard(GraphicsContext g, Image card_img, int r, int c)
    {
        g.drawImage(card_img, 10+25+((c)*tileLengths), 10+25+((r)*tileLengths),tileLengths,tileLengths);
    }

    public Image stringToImage(String imageName)
    {
        if("Vestibule".equals(imageName))
            return Vestibule_img;
        if("AcidJets".equals(imageName))
            return AcidJets_img;
        if("ArrowTraps".equals(imageName))
            return ArrowTraps_img;
        if("Blank".equals(imageName))
            return Blank_img;
        if("DarkSlime".equals(imageName))
            return DarkSlime_img;
        if("DenOfSnakes".equals(imageName))
            return DenOfSnakes_img;
        if("Dragonling".equals(imageName))
            return Dragonling_img;
        if("FelKnight".equals(imageName))
            return FelKnight_img;
        if("FireOfEidolon".equals(imageName))
            return FireOfEidolon_img;
        if("FloatingStones".equals(imageName))
            return FloatingStones_img;
        if("HallOfIllusion".equals(imageName))
            return HallOfIllusion_img;
        if("LaughingShadow".equals(imageName))
            return LaughingShadow_img;
        if("LavaLake".equals(imageName))
            return LavaLake_img;
        if("MimicChest".equals(imageName))
            return MimicChest_img;
        if("MindEater".equals(imageName))
            return MindEater_img;
        if("Minotaur".equals(imageName))
            return Minotaur_img;
        if("NewExit".equals(imageName))
            return NewExit_img;
        if("OgreBrute".equals(imageName))
            return OgreBrute_img;
        if("ParadoxPuzzle".equals(imageName))
            return ParadoxPuzzle_img;
        if("PendulumBlades".equals(imageName))
            return PendulumBlades_img;
        if("Psychomancer".equals(imageName))
            return Psychomancer_img;
        if("SecretPassageX".equals(imageName))
            return SecretPassageX_img;
        if("SecretPassageY".equals(imageName))
            return SecretPassageY_img;
        if("SkeletalGuards".equals(imageName))
            return SkeletalGuards_img;
        if("SphynxsRiddle".equals(imageName))
            return SphynxsRiddle_img;
        if("SpikedPit".equals(imageName))
            return SpikedPit_img;
        if("VoraciousPlant".equals(imageName))
            return VoraciousPlant_img;
        if("VoraxsFocus".equals(imageName))
            return VoraxsFocus_img;
        if("VoraxsHeart".equals(imageName))
            return VoraxsHeart_img;
        if("VoraxsKnowledge".equals(imageName))
            return VoraxsKnowledge_img;
        return null;
    }

    public void drawClickToPlayPage(GraphicsContext g)
    {
        g.setFill(Color.BLACK);
        g.fillRect(0,0,canvasWidth,canvasHeight);
        g.setStroke(Color.WHITE);
        g.strokeText("Click Anywhere to Play \n Make Sure to select your number of players",400,400);
    }
    public void drawSelectingPlayerAndClassesPage(GraphicsContext g)
    {
        g.setFill(Color.BLACK);
        g.fillRect(0,0,canvasWidth,canvasHeight);
        gc.setStroke(Color.WHITE);
        gc.strokeText("Click anywhere on the black screen to continue",400,400);


    }
    public void drawPlayPage(GraphicsContext g)
    {
        g.setFill(Color.DIMGREY);
        g.fillRect(0,0,canvasWidth,canvasHeight);
        g.setStroke(Color.WHITE);
        for (int r = 0; r < 9; r++) {
            for (int c = 0; c < 9; c++) {
                g.strokeRect(10+25+((c)*tileLengths),10+25+((r)*tileLengths),tileLengths,tileLengths);
            }
        }
        g.drawImage(Outline, 10,10,Outline.getWidth(), Outline.getHeight());
        g.drawImage(Vestibule_img,10+25+(4*tileLengths),10+25+(4*tileLengths),tileLengths,tileLengths);
        g.setStroke(Color.YELLOW);
        g.setFill(Color.WHITE);
        g.fillRect(10+Outline.getWidth()+20+.01,10+20+.01, tileLengths-.01, tileLengths-.01);
        g.strokeRect(10+Outline.getWidth()+20,10+20,tileLengths,tileLengths);

        player1_lbl.setVisible(false);
        player2_lbl.setVisible(false);
        player3_lbl.setVisible(false);
        player4_lbl.setVisible(false);
        player5_lbl.setVisible(false);
        player6_lbl.setVisible(false);
        Player1Class_CB.setVisible(false);
        Player2Class_CB.setVisible(false);
        Player3Class_CB.setVisible(false);
        Player4Class_CB.setVisible(false);
        Player5Class_CB.setVisible(false);
        Player6Class_CB.setVisible(false);

        for (int i = 0; i < NumOfPlayers; i++) {
            if(i==0)
            {
                drawPlayerClasses(g,i+1,Player1_Class);
            }
            if(i==1)
            {
                drawPlayerClasses(g,i+1,Player2_Class);
            }
            if(i==2)
            {
                drawPlayerClasses(g,i+1,Player3_Class);
            }
            if(i==3)
            {
                drawPlayerClasses(g,i+1,Player4_Class);
            }
            if(i==4)
            {
                drawPlayerClasses(g,i+1,Player5_Class);
            }
            if(i==5)
            {
                drawPlayerClasses(g,i+1,Player6_Class);
            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
