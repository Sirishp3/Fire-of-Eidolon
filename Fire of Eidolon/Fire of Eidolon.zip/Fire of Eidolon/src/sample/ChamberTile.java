package sample;

public interface ChamberTile {
    public int getRow();
    public int getColumn();
    public void setRow(int r);
    public void setColumn(int c);
}
